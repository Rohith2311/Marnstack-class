module.exports = () => {
    return {
        id: 'website',
        public: true,
        restricted: true
    };
};