module.exports = () => {
    return {
        id: 'occupant',
        restricted: true
    };
};