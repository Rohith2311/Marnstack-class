module.exports = () => {
    return {
        id: 'property',
        restricted: true
    };
};