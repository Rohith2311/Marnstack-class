module.exports = () => {
    return {
        id: 'realm',
        restricted: true
    };
};