module.exports = () => {
    return {
        id: 'rent',
        params: '/:year?/:month?',
        restricted: true
    };
};