module.exports = () => {
    return {
        id: 'owner',
        restricted: true
    };
};