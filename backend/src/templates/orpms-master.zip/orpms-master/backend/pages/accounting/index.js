module.exports = () => {
    return {
        id: 'accounting',
        params: '/:year?/:month?',
        restricted: true
    };
};