module.exports = () => {
    return {
        id: 'profile',
        restricted: true
    };
};