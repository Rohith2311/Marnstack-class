module.exports = () => {
    return {
        id: 'dashboard',
        restricted: true
    };
};