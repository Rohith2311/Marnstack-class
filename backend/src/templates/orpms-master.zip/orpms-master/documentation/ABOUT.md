# About Loca

Why pay hundreds of dollars for an overpriced, problematic and confusing rental property management software, when you can create a similar and simple app to your taste and preferences,
without any  of the complex or complicated features… and best of all, absolutely free to use anytime, anywhere?

This is the underlying philosophy behind the creation and development of Loca by its Lead Developer, Camel Aissani.
A rental property manager by profession who also enjoys Software Development and Coding as a part time hobby.

From the initial plan of creating Loca to help himself and his fellow rental property manager cum friend in their businesses, Loca has evolved
into a user-friendly, durable and no-cost solution for rental property management.

Loca is ideal for small, independent landlords and property managers to effectively manage their businesses, keep accurate and secure rental records,
significantly reduce the need for making frequent, costly phone calls to tenants and vendors and avoid most of the tiresome paperwork associated with managing a rental property.

Our promise to you our esteemed clients is that Loca will be a welcome solution to your rental management needs,
not an additional problem.


Thank You For Using Loca Today.
